#!/bin/bash

dotnet build -o geektrust
dotnet geektrust/geektrust.dll sample_input/input1.txt