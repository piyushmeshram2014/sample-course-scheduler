﻿using GeekTrust.src.core.CourseScheduler.Core.Constants;
using GeekTrust.src.core.CourseScheduler.Core.DTO;
using GeekTrust.src.core.CourseScheduler.Core.ErrorHandlers;
using GeekTrust.src.web;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;

namespace GeekTrust
{
    class Program
    {
        static readonly string rootFolder = @"C:\Users\PMESHRAM\Downloads\csharp-dotnet\csharp-starter-kit\GeekTrust\sample_input\input4.txt";
        //Default file. MAKE SURE TO CHANGE THIS LOCATION AND FILE PATH TO YOUR FILE   
        static readonly string textFile = @"C:\Users\PMESHRAM\Downloads\csharp-dotnet\csharp-starter-kit\GeekTrust\sample_input\input4.txt";
        static List<string> commandList = new List<string>() { "ADD-COURSE-OFFERING", "REGISTER", "ALLOT", "CANCEL" };
        static List<int> commandArgumentsSize = new List<int>() { 5,2,1,1 };


        static void Main(string[] args)
        {
            try
            {
                if (File.Exists(args[0]))
                { 
                    //string[] lines = File.ReadAllLines(textFile);
                    string[] lines = File.ReadAllLines(args[0]);
                    foreach (string line in lines)
                    {
                        string[] commandWithArguments = line.Split(" ");
                        string command = commandWithArguments[0];

                        List<string> argumentList = new List<string>();

                        for (int i = 1;i < commandWithArguments.Length;i++)
                            argumentList.Add(commandWithArguments[i]);
                        ProcessCommands(command, argumentList);
                    }
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void ProcessCommands(string command, List<string> argumentList)
        {
            Controller controller = new Controller();
            try
            {
                if (command == commandList[0])
                    AddCourseOffering(controller,argumentList);
                else if (command == commandList[1])
                    RegisterUserForCourse(controller, argumentList);
                
                else if (command == commandList[2])
                    AllotCourse(controller, argumentList);
                
                else if (command == commandList[3])
                    CancelRegistration(controller,argumentList);
                else
                    Console.WriteLine(ErrorCodes.INPUT_DATA_ERROR);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void CancelRegistration(Controller controller, List<string> argumentList)
        {
            if (argumentList.Count() != commandArgumentsSize[3])
                Console.WriteLine(ErrorCodes.INPUT_DATA_ERROR);

            var obj = ValidateAndBuildRegistrationObjectForCancel(argumentList);
            string response = controller.CancelRegistration(obj);
            Console.WriteLine(response);
        }

        private static void AllotCourse(Controller controller, List<string> argumentList)
        {
            if (argumentList.Count() != commandArgumentsSize[2])
                Console.WriteLine(ErrorCodes.INPUT_DATA_ERROR);
            else
            {
                var course = ValidateAndBuildCourseObjectForAllot(argumentList);
                var response = controller.AllotCourse(course);
                response = response.OrderBy(t => t.RegistrationId).ToList();

                if (response == null)       //no output
                    Console.WriteLine(ErrorCodes.INPUT_DATA_ERROR);
                else
                {
                    foreach (var item in response)
                    {
                        if (item.Status == REGISTERSTATUS.CONFIRMED || item.Status == REGISTERSTATUS.COURSE_CANCELED)
                            Console.WriteLine(item.RegistrationId + " " + item.User.EmailId + " " + item.Course.CourseOfferingId + " " + item.Course.Title + " " + item.Course.Instructor + " " + item.Course.OfferingDate + " " + item.Status);
                    }
                }
            }
        }

        private static void RegisterUserForCourse(Controller controller, List<string> argumentList)
        {
            if (argumentList.Count() != commandArgumentsSize[1])
                Console.WriteLine(ErrorCodes.INPUT_DATA_ERROR);

            else
            {
                var obj = ValidateRegistrationObject(argumentList);

                var response = controller.RegisterUser(obj.User, obj.Course);
                if (response == null)
                    Console.WriteLine(ErrorCodes.COURSE_FULL_ERROR.ToString());
                else
                {
                    Console.WriteLine(response.RegistrationId + " " + response.Status);
                }
            }
        }

        private static void AddCourseOffering(Controller controller, List<string> argumentList)
        {
            if (argumentList.Count() != commandArgumentsSize[0])
                Console.WriteLine(ErrorCodes.INPUT_DATA_ERROR);
            else
            {
                var obj = ValidateCourseObject(argumentList);

                var response = controller.AddCourse(obj);
                Console.WriteLine(response.CourseOfferingId);
            }
        }

        private static RegistrationDTO ValidateAndBuildRegistrationObjectForCancel(List<string> argumentList)
        {
            bool isValid = true;

            string regId = argumentList[0];

            return new RegistrationDTO(regId);
        }

        private static CourseDTO ValidateAndBuildCourseObjectForAllot(List<string> argumentList)
        {
            string courseid = argumentList[0];
            return new CourseDTO(courseid);
        }

        private static CourseDTO ValidateCourseObject(List<string> argumentList)
        {
            bool isValid = ValidateCourseDetails(argumentList);
            if (isValid)
            {
                CourseDTO course = new CourseDTO(argumentList[0], argumentList[1], argumentList[2], int.Parse(argumentList[3]), int.Parse(argumentList[4]));
                return course;
            }
            return null;
        }

        private static bool ValidateCourseDetails(List<string> argumentList)
        {
            bool isValid = true;
            string dateCourse = argumentList[2];

            if (dateCourse.Length != 8)
            {
                isValid = false;
                Console.WriteLine("INPUT_DATA_ERROR");
            }

            int minCt;
            var isMinCountInteger = int.TryParse(argumentList[3], out minCt);
            if (!isMinCountInteger)
            {
                isValid = false;
                Console.WriteLine("INPUT_DATA_ERROR");
            }

            int maxCt;
            var isMaxCountInteger = int.TryParse(argumentList[4], out maxCt);
            if (!isMaxCountInteger)
            {
                isValid = false;
                Console.WriteLine("INPUT_DATA_ERROR");
            }

            return isValid;
        }

        private static RegistrationDTO ValidateRegistrationObject(List<string> argumentList)
        {
            bool isValid = true;

            string userEmail = argumentList[0];
            string courseId = argumentList[1];

            Regex regex = new Regex(@"^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$");
            Match match = regex.Match(userEmail);
            if (!match.Success)
            {
                isValid = false;
                Console.WriteLine("INPUT_DATA_ERROR");
            }

            UserDTO user = new UserDTO(userEmail);
            CourseDTO course = new CourseDTO(courseId);

            if (isValid)
            {
                RegistrationDTO reg = new RegistrationDTO(user, course);
                return reg;
            }
            return null;
        }
    }
}
