﻿using GeekTrust.src.core.CourseScheduler.Core.DTO;
using GeekTrust.src.core.CourseScheduler.ServiceLayer;
using GeekTrust.src.core.CourseScheduler.ServiceLayer.Services;
using System;
using System.Collections.Generic;
using System.Text;

namespace GeekTrust.src.web
{
    public class Controller
    {

        public Controller()
        {
        }

        public CourseDTO AddCourse(CourseDTO course)
        {
            ICourseSchedulerService obj = new CourseSchedulerService();

            CourseDTO response = obj.AddCourse(course);

            return response;
        }

        public RegistrationDTO RegisterUser(UserDTO user ,CourseDTO course)
        {
            ICourseSchedulerService obj = new CourseSchedulerService();

            RegistrationDTO response = obj.RegisterUser(user, course);

            if (response == null)
            {
                return null;
                //return "COURSE_FULL";
            }

            return response;
        }

        public List<RegistrationDTO> AllotCourse(CourseDTO course)
        {
            ICourseSchedulerService obj = new CourseSchedulerService();

            List<RegistrationDTO> response = obj.AllotCourse(course);

            return response;
        }

        public string CancelRegistration(RegistrationDTO registration)
        {
            ICourseSchedulerService obj = new CourseSchedulerService();

            var response = obj.CancelRegistration(registration);

            return response;
        }

    }
}
