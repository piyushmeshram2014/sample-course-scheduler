﻿using GeekTrust.src.core.CourseScheduler.Core.DTO;
using System;
using System.Collections.Generic;
using System.Text;

namespace GeekTrust.src.core.CourseScheduler.ServiceLayer.Services
{
    public interface ICourseSchedulerService
    {
        CourseDTO AddCourse(CourseDTO course);

        RegistrationDTO RegisterUser(UserDTO user, CourseDTO course);

        List<RegistrationDTO> AllotCourse(CourseDTO course);

        string CancelRegistration(RegistrationDTO registration);

    }
}
