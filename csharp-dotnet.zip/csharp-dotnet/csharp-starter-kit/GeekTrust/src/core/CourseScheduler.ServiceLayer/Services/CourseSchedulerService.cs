﻿using GeekTrust.src.core.CourseScheduler.Core.Constants;
using GeekTrust.src.core.CourseScheduler.Core.DTO;
using GeekTrust.src.core.CourseScheduler.ServiceLayer.Services;
using GeekTrust.src.infrastructure.repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GeekTrust.src.core.CourseScheduler.ServiceLayer
{
    public class CourseSchedulerService : ICourseSchedulerService
    {
        public CourseDTO AddCourse(CourseDTO course)
        {
            course.Validate();

            CourseRepository.AddCourse(course);

            return course;      //with updated value of CourseOfferingId
        }

        public RegistrationDTO RegisterUser(UserDTO user, CourseDTO course)
        {
            user.Validate();

            var matchingCourse = CourseRepository.GetCourseOfferingId(course);

            if (matchingCourse == null)
                throw new Exception("INPUT_DATA_ERROR");

            var response = RegistrationRepository.RegisterUser(user, matchingCourse);

            if (response == null)
                return null;
            return response;
        }

        public List<RegistrationDTO> AllotCourse(CourseDTO course)
        {
            var response = RegistrationRepository.AllotCourse(course);

            return response;
        }

        public string CancelRegistration(RegistrationDTO registration)
        {
            var response = RegistrationRepository.CancelRegistration(registration);

            if (response == null)
                return "INPUT_DATA_ERROR";

            else
                return response.RegistrationId + " " + response.Status;

        }

    }
}
