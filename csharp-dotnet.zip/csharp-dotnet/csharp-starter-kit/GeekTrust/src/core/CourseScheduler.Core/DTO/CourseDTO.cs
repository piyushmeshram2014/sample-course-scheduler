﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GeekTrust.src.core.CourseScheduler.Core.DTO
{
    public class CourseDTO
    {
        public static readonly string TypeName = typeof(CourseDTO).FullName;

        public CourseDTO(string courseOfferingId)
        {
            CourseOfferingId = courseOfferingId;
        }

        public CourseDTO(string title, string instructor, string dateObj, int minCt, int maxCt)
        {
            Title = title;
            Instructor = instructor;
            OfferingDate = dateObj;
            MinCount = minCt;
            MaxCount = maxCt;
        }

        public string Title { get; set; }

        public string Instructor { get; set; }

        public string OfferingDate { get; set; }

        public int MinCount { get; set; }

        public int MaxCount { get; set; }

        private string _courseOfferingId;

        //OFFERING-<COURSE-NAME>-<INSTRUCTOR>
        public string CourseOfferingId
        {
            get
            {
                if (_courseOfferingId == null)
                {
                    if (Title != null && Instructor != null)
                    {
                        return "OFFERING-" + Title + "-" + Instructor;
                    }
                    else
                        return String.Empty;
                }
                return _courseOfferingId;
            }
            set
            {
                _courseOfferingId = value;
            }
        }


        internal void Validate()
        {
            if (Title == null)
                throw new Exception("INPUT_DATA_ERROR");

            if (Instructor == null)
                throw new Exception("INPUT_DATA_ERROR");

            if (OfferingDate == null)
                throw new Exception("INPUT_DATA_ERROR");
        }

    }
}
