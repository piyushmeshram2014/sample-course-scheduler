﻿using GeekTrust.src.core.CourseScheduler.Core.Constants;
using GeekTrust.src.infrastructure.repository;
using System;
using System.Collections.Generic;
using System.Text;

namespace GeekTrust.src.core.CourseScheduler.Core.DTO
{
    public class RegistrationDTO
    {
        public static readonly string TypeName = typeof(RegistrationDTO).FullName;

        public RegistrationDTO(string regId)
        {
            this.RegistrationId = regId;
        }

        public RegistrationDTO(UserDTO user,CourseDTO course)
        {
            this.User = user;
            this.Course = course;
        }

        public RegistrationDTO(UserDTO user, CourseDTO course, REGISTERSTATUS status)
        {
            User = user;
            Course = course;
            this.Status = status;
        }

        public UserDTO User { get; set; }

        public CourseDTO Course { get; set; }

        public REGISTERSTATUS Status { get; set; }

        private string _registrationId;

        //REG-COURSE-<EMPLOYEE-NAME>-<COURSE-NAME>
        public string RegistrationId 
        {
            get
            {
                if (_registrationId == null)
                {
                    if (User != null && Course != null)
                    {
                        return "REG-COURSE-" + User.UserName + "-" + Course.Title;
                    }
                    else
                        return String.Empty;
                }
                else
                    return _registrationId;

            }
            set
            {
                _registrationId = value;
            }
        }

    }
}
