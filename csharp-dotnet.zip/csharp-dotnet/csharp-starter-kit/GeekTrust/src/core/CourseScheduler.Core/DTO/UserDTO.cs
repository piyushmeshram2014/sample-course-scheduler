﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GeekTrust.src.core.CourseScheduler.Core.DTO
{
    public class UserDTO
    {
        public UserDTO(string userEmail)
        {
            EmailId = userEmail;
        }

        public int Userid { get; set; }

        public string UserName 
        {
            get
            {
                if(EmailId != null)
                {
                    return EmailId.Split('@')[0];
                }
                return "";
            }
        }

        public string EmailId { get; set; }     //validate this

        internal void Validate()
        {
            if (EmailId == null)
                throw new Exception("INPUT_DATA_ERROR ");
        }
    }
}
