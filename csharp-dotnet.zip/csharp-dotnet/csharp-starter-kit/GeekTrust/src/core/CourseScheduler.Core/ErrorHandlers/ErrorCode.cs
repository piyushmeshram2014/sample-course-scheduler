﻿namespace GeekTrust.src.core.CourseScheduler.Core.ErrorHandlers
{
        public enum ErrorCodes
        {
            INPUT_DATA_ERROR, 
            COURSE_FULL_ERROR,
        }
}
