﻿namespace GeekTrust.src.core.CourseScheduler.Core.Constants
{
    public enum REGISTERSTATUS
    {
        UNASSIGNED,
        ACCEPTED,
        CONFIRMED,
        CANCEL_ACCEPTED,
        CANCEL_REJECTED,
        COURSE_CANCELED
    }
}
