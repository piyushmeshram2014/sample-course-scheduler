﻿using GeekTrust.src.core.CourseScheduler.Core.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GeekTrust.src.infrastructure.repository
{
    public class CourseRepository
    {
        static List<CourseDTO> courses = null;

        internal static void AddCourse(CourseDTO course)
        {
            if(courses == null)
            {
                courses = new List<CourseDTO>();
            }

            courses.Add(course);
        }

        internal static CourseDTO GetCourseOfferingId(CourseDTO course)
        {
            if (courses != null)
            {
                var matchingCourse = courses.Where(t => t.CourseOfferingId == course.CourseOfferingId);

                return matchingCourse.FirstOrDefault();
            }
            else
                return null;
        }
    }
}
