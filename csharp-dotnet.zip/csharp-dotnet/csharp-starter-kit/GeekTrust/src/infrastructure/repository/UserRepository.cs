﻿using GeekTrust.src.core.CourseScheduler.Core.DTO;
using System;
using System.Collections.Generic;
using System.Text;

namespace GeekTrust.src.infrastructure.repository
{
    public class UserRepository
    {
        static List<UserDTO> users = null;
    }
}
