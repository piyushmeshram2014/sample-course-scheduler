﻿using GeekTrust.src.core.CourseScheduler.Core.Constants;
using GeekTrust.src.core.CourseScheduler.Core.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GeekTrust.src.infrastructure.repository
{
    public class RegistrationRepository
    {
        static List<RegistrationDTO> registrationList = null;

        internal static RegistrationDTO RegisterUser(UserDTO user, CourseDTO course)
        {
            if (registrationList == null)
            {
                registrationList = new List<RegistrationDTO>();
            }

            var currentCountOfRegistrationsWithCourse = GetRegistrationCountForCourse(course);

            if (currentCountOfRegistrationsWithCourse + 1 > course.MaxCount)
                return null;

            RegistrationDTO registrationObject = new RegistrationDTO(user, course, REGISTERSTATUS.ACCEPTED);

            registrationList.Add(registrationObject);

            return registrationObject;
        }

        private static int GetRegistrationCountForCourse(CourseDTO course)
        {
            if (registrationList != null)
            {
                var response = registrationList.Where(t => t.Course.CourseOfferingId == course.CourseOfferingId).Count();
                return response;
            }
            return 0;
        }

        internal static List<RegistrationDTO> AllotCourse(CourseDTO course)
        {
            if (registrationList != null)
            {
                var listOfRegistrationsWithAcceptedStatus = registrationList.Where(t => t.Course.CourseOfferingId == course.CourseOfferingId);
                course = CourseRepository.GetCourseOfferingId(course);

                long acceptedApplications = 0;

                foreach (var item in listOfRegistrationsWithAcceptedStatus)
                {
                    if (item.Status == REGISTERSTATUS.ACCEPTED)
                    {
                        acceptedApplications++;
                    }
                }
                if (acceptedApplications < course.MinCount)
                {
                    foreach (var item in listOfRegistrationsWithAcceptedStatus)
                    {
                        if (item.Status == REGISTERSTATUS.ACCEPTED)
                            item.Status = REGISTERSTATUS.COURSE_CANCELED;
                    }
                }
                else
                {
                    foreach (var item in listOfRegistrationsWithAcceptedStatus)
                    {
                        if (item.Status == REGISTERSTATUS.ACCEPTED)
                            item.Status = REGISTERSTATUS.CONFIRMED;
                    }
                }
                return registrationList;
            }
            return null;
        }

        internal static List<RegistrationDTO> GetRegistrationList()
        {
            return registrationList;
        }


        internal static RegistrationDTO CancelRegistration(RegistrationDTO registration)
        {
            var registrationList = RegistrationRepository.GetRegistrationList();

            var regId = registrationList.Where(t => t.RegistrationId == registration.RegistrationId);       //expect only one regid

            REGISTERSTATUS resultStatus = REGISTERSTATUS.UNASSIGNED;

            if (regId.Count() != 0)
            {
                //regid found
                var registrationObj = regId.First();
                var regStatus = regId.First().Status;
                if (regStatus == REGISTERSTATUS.ACCEPTED)
                {
                    resultStatus = REGISTERSTATUS.CANCEL_ACCEPTED;
                }
                else
                {
                    resultStatus = REGISTERSTATUS.CANCEL_REJECTED;
                }
                registrationObj.Status = resultStatus;

                return registrationObj;
            }
            else
                return null;
            
        }
    }
}
